// $("#target").click(function () {
//   alert("Handler for .click() called.");
// });
// alert("Handler for .click() called.");

//Add Input Fields
$(document).ready(function() {
    var max_fields = 10; //Maximum allowed input fields 
    var wrapper    = $(".wrapper"); //Input fields wrapper
    var add_button = $(".add_fields"); //Add button class or ID
    var x = 1; //Initial input field is set to 1
 
 //When user click on add input button
 $(add_button).click(function(e){
        e.preventDefault();
 //Check maximum allowed input fields
        if(x < max_fields){ 
            x++; //input field increment
 //add input field
//  $(wrapper).append('<div class="row"><input type="text" name="input_array_name[]" placeholder="Input Text Here" /> <a href="javascript:void(0);" class="remove_field">Remove</a></div>');
 $(wrapper).append('<div class="row"><div class="col-md-3 mb-3"><label for="shortname">shortname</label><input type="text" class="form-control" id="shortname[]" name="shortname[]" required /></div><div class="col-md-3 mb-3"><label for="fullname">fullname</label><input type="text" class="form-control" id="fullname[]" name="fullname[]" required /></div><div class="col-md-3 mb-3"><label for="idnumber">idnumber</label><input type="text" class="form-control" id="idnumber[]" name="idnumber[]" required /></div><div class="col-md-3 mb-3"><label for="category_idnumber">category_idnumber</label><input type="text" class="form-control" id="category_idnumber" name="category_idnumber" required /></div></div>');
        }
    });
 
    //when user click on remove button
    $(wrapper).on("click",".remove_field", function(e){ 
        e.preventDefault();
 $(this).parent('div').remove(); //remove inout field
 x--; //inout field decrement
    })
});
