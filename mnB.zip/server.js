const express = require("express");
const app = express();
const port = 3000;

const fs = require("fs");

// app.get("/", (req, res) => {
//   res.send("Hello World!");
// });
app.get("/registrar", (req, res) => {
  res.send(req.query);

  user =
    "\n" +
    req.query.username +
    "," +
    req.query.password +
    "," +
    req.query.firstName +
    "," +
    req.query.lastName +
    "," +
    req.query.email +
    "," +
    req.query.cohort1 +
    "," +
    req.query.course1 +
    "," +
    req.query.type1;
    //  +
    // ";";
  fs.appendFile("./user.csv", user, function (err, data) {
    if (err) {
      return console.log(err);
    }
    console.log(data);
  });
  cursos = "";
  req.query.shortname.forEach((element, i) => {
    cursos =
      "\n" +
      req.query.shortname[i] +
      "," +
      req.query.fullname[i] +
      "," +
      req.query.idnumber[i] +
      "," +
      req.query.category_idnumber[i];
      //  +
      // ";";
    fs.appendFile("./cursos.csv", cursos, function (err, data) {
      if (err) {
        return console.log(err);
      }
      console.log(data);
    });
  });
});
app.use(express.static("public"));

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
